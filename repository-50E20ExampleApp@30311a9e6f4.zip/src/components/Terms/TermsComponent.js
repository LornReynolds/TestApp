import React, {Component} from 'react';

class TermsComponent extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount = () => {
    }

    componentWillUnmount = () => {
    }

    render = () => {
        return (
            <div className="container text-center">Terms Component!</div>
        )
    }
}
export default TermsComponent;