import React, {Component} from 'react';

class MetricsDashboardComponent extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount = () => {
    }

    componentWillUnmount = () => {
    }

    render = () => {
        return (
            <div className="container text-center">Metrics Dashboard Component!</div>
        )
    }
}
export default MetricsDashboardComponent;