import React, {Component} from 'react';

class SupportComponent extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount = () => {
    }

    componentWillUnmount = () => {
    }

    render = () => {
        return (
            <div className="container text-center">Support Component!</div>
        )
    }
}
export default SupportComponent;