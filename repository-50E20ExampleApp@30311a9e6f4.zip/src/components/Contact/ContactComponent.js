import React, {Component} from 'react';

class ContactComponent extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount = () => {
    }

    componentWillUnmount = () => {
    }

    render = () => {
        return (
            <div className="container text-center">Contact Component!</div>
        )
    }
}
export default ContactComponent;