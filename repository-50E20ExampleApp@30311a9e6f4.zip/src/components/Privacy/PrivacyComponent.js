import React, {Component} from 'react';

class PrivacyComponent extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount = () => {
    }

    componentWillUnmount = () => {
    }

    render = () => {
        return (
            <div className="container text-center">Privacy Component!</div>
        )
    }
}
export default PrivacyComponent;