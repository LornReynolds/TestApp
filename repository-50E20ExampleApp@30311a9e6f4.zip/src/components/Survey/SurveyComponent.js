import React, {Component} from 'react';

class SurveyComponent extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount = () => {
    }

    componentWillUnmount = () => {
    }

    render = () => {
        return (
            <div className="container text-center">Survey Component!</div>
        )
    }
}
export default SurveyComponent;